import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

n = 10                                     # total Ca number in the box
L = 25001                                  # number of points in trajectory, which is nsteps in .mdp file
dt = 1                                     # time increment between each point, unit is ps.
twin = 10                                  # allow water to leave shell temporarily, unit is ps. 
tmax = 5000                                # length of correlation function, unit is ps 
M = int(L - tmax/dt - twin/dt)             # number of time origins
N = int(tmax/dt + 1)                       # number of points in correlation function
t = np.arange(0,(tmax+1)*0.2,step=dt*0.2)  # time points in correlation function

def rtcf(trj):
    c = np.zeros(N)
    norm = 0
    for i in range(0,M):                   # loop over time origins
        for water in trj[i]:               # loop over water
            for t in range(0,N):           # loop over delay time
                window = list()
                for j in range(1,twin+1):
                    window = window + trj[i+t+j]
                if water in trj[i+t]:
                    c[t] = c[t] + 1
                elif water in window:
                    c[t] = c[t] + 1
                    
            window = list()                # normalization factor
            for j in range(1,twin+1):
                window = window + trj[i+j]                 
            if water in trj[i]:
                norm = norm + 1
            elif water in window:
                norm = norm + 1
    return c/norm
                
def exp(t,n,ts):
    return n*np.exp(-t/ts)

corr_func = np.zeros(N)
popt = [0,0]

for i in range(1,n+1):    
    trj = list()
    with open('1st-Ca'+str(i)+'.txt', 'r',encoding='utf-8') as f:
        for line in f:
            trj.append(line.split())
    temp = rtcf(trj)
    popt_temp, pcov_temp = curve_fit(exp, t, temp)
    corr_func = corr_func + temp/n
    popt = popt + popt_temp/n

fig = plt.figure(figsize=(10,7.5))
ax = fig.add_subplot(111)

ax.plot(t,corr_func,'b',lw=2.0,label='Correlation function')
ax.plot(t,exp(t,*popt),'r',lw=2.0,label='Exponential decay fit')
ax.legend(fontsize=25)
ax.set_xlabel('t /ps', size=25)
ax.set_ylabel('Residence time correlation function', size=25)
ax.tick_params(axis='both',which='major',labelsize=20)
plt.savefig('Ca-1st.png',dpi=300)
np.savetxt('Ca-1st.txt',np.transpose((t,corr_func)))
np.savetxt('Ca-1st-popt.txt',np.transpose(popt))
print('tau = ' + str(popt[1]) + ' ps')
