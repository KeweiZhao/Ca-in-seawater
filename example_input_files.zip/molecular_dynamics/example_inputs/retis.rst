Retis 1D
================

Simulation
----------
task = retis
steps = 10000
interfaces = [0.20,0.21,0.22,0.23,0.24,0.25,0.26,0.27,0.28,0.29,0.30,0.41]

System
------
units = gromacs

Engine settings
---------------
class = gromacs2
gmx = gmx
mdrun = gmx mdrun -ntmpi 1 -ntomp 1
input_path = gromacs_input
timestep = 0.002
subcycles = 5
gmx_format = gro
maxwarn = 1

TIS settings
------------
freq = 0.5
maxlength = 1000000
aimless = True
allowmaxlength = False
zero_momentum = False
rescale_energy = False
sigma_v = -1
seed = 0

RETIS settings
--------------
swapfreq = 0.5
relative_shoots = None
nullmoves = True
swapsimul = True

Initial-path
------------
method = kick
kick-from = previous

Orderparameter
--------------
class = Distance
index = (4052, 68)
periodic = True

Output
------
order-file = 1